import javax.swing.text.html.parser.Parser;
import java.util.Random;
import java.util.Scanner;

public class PredinhoMatador {

    public static void main(String[] args) {

        System.out.print("Input your name: ");
        //classe Scanner para direcionar uma leiura
        Scanner name = new Scanner(System.in);
        String  nome= name.nextLine();
        //----digite sua idade-----
        System.out.print("Whats your age: ");
        Scanner age = new Scanner(System.in);
        int idade=age.nextInt();

        System.out.print("Sua cidade/pais: ");
        Scanner estado =  new Scanner(System.in);
        String est = age.next();

        //Metodo randomico para se criar numeros aleatorios
        Random rand = new Random();
        //o valor Aleatorio será armazenado no valor int até 1000
        int id = rand.nextInt(1000);

        String[] usuario= new String[4];
        usuario[0] = nome;
        usuario[1] = Integer.toString(idade);
        usuario[2] = est;
        usuario[3] = Integer.toString(id);

//        if (idade ! String)
        System.out.println("Sua idade é: " + usuario[0] +
                "\nSeu nome é: " + usuario[1] +
                "\nSua Cidade: "+ usuario[2]+
                "\nSeu id será: "+ usuario[3]);
    }

}

import java.util.Scanner;

public class temperatura {
    public static void main(String[] args) {
        System.out.print("Digite a temperatura em Graus Celsius para se converter em fahrenhei: ");
        Scanner g = new Scanner(System.in);
        double graus = g.nextByte();

        double fahrenhei = graus * 1.8 + 32;
        System.out.println("Em fahrenhei: " + fahrenhei);
    }
}

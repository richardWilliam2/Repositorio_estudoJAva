import java.util.Random;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        System.out.print("Digite um numero entre 0 a 20: ");

        Scanner input = new Scanner(System.in);
        int dig = input.nextInt();

        Random random = new Random();
        int num = random.nextInt(20);

        System.out.println("Seu numero digitado é: "+dig+
                "\nNumero sortiado: "+num);

        int tentativas = 1;

        while (dig != num){
            System.out.println("Errou feio ein!, Tente de novo!");
            System.out.print("Digite um numero: ");
            dig = input.nextInt();
            tentativas++;
        }

        System.out.println("O gloria finalmente ein");
        System.out.println("Tentativas: "+tentativas);

    }

}
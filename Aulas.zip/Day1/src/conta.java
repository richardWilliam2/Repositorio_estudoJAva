import java.util.Scanner;

public class conta {
    public static void main(String[] args) {
        System.out.print("Digite um numero: ");
        Scanner n1 = new Scanner(System.in);
        int num1 = n1.nextInt();
        System.out.print("Digite outro numero: ");
        Scanner n2 = new Scanner(System.in);
        int num2 = n2.nextInt();

        int soma = num1 + num2;
        int multiplicao = num1 * num2;
        int subtracao = num1 - num2;

        System.out.println("A Soma: "+soma+
                "\nA subtração: "+ subtracao+
                "\nA Multiplicação; "+multiplicao);
    }
}
